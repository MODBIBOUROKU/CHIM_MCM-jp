xTranslatorで
Scripts > AIAgentMCMConfigScript.pex
に使用して訳してください

==============================================================

元MOD: CHIM - Pair Any NPC（作者: rang97）
https://www.nexusmods.com/skyrimspecialedition/mods/126330
本ファイルは、MCMメニューの非公式日本語翻訳です
すべてのオリジナルアセットは rang97 氏に帰属します